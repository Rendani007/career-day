<?php $__env->startSection('title', 'Add School'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded shadow p-6 max-w-xl mx-auto">
    <form method="POST" action="<?php echo e(route('admin.schools.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label class="block font-semibold mb-1">School Name</label>
            <input type="text" name="name" required class="w-full border rounded p-2" />
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Save School
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MBC Website\career-day\resources\views/admin/schools/create.blade.php ENDPATH**/ ?>