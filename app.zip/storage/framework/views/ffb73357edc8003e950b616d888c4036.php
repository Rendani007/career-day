<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto p-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">All Events</h2>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2"><?php echo e($event->name); ?></h3>
                <p class="text-sm text-gray-500 mb-4"><?php echo e($event->days->count()); ?> Day(s)</p>
                <ul class="text-sm text-gray-700 list-disc pl-5">
                    <?php $__currentLoopData = $event->days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-1">
                            <strong><?php echo e($day->name); ?>:</strong>
                            <?php echo e($day->industries->pluck('name')->join(', ')); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\MBC Website\career-day\resources\views//admin/dashboard.blade.php ENDPATH**/ ?>